package com.company;

public class Garage<A extends Car> implements Movable {

    @Override
    public int addMileage(Object o) {
        return 0;
    }
}
