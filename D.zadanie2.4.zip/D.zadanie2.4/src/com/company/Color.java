package com.company;

public enum Color {
    GREEN,
    BLACK,
    WHITE,
    BLUE,
    SILVER
}
