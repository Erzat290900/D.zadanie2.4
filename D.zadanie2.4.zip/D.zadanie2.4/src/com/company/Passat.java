package com.company;

public class Passat extends Car{
    public Passat(int year, Color color) {
        super(year, color);
    }
}
