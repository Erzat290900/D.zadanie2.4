package com.company;

public interface Movable <A>{
    public int addMileage(A a);
}
