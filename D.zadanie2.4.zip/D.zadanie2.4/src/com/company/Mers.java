package com.company;

public class Mers extends Car{
    public Mers(int year, Color color) {
        super(year, color);
    }
}
