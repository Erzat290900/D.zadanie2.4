package com.company;

public class Bmw extends Car{
    public Bmw(int year, Color color) {
        super(year, color);
    }
}
